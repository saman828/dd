<html lang="en" class=" js flexbox flexboxlegacy canvas canvastext webgl no-touch geolocation postmessage websqldatabase indexeddb hashchange history draganddrop websockets rgba hsla multiplebgs backgroundsize borderimage borderradius boxshadow textshadow opacity cssanimations csscolumns cssgradients cssreflections csstransforms csstransforms3d csstransitions fontface no-generatedcontent video audio localstorage sessionstorage webworkers applicationcache svg inlinesvg smil svgclippaths"><head><meta charset="utf-8"><title>
	درگاه پرداخت اینترنتی پرداخت الکترونیک سامان
</title><meta name="viewport" content="width=device-width, initial-scale=1.0"><script src="js/modernizr"></script>

    <script src="js/persian.js"></script>
<script src="js/Payment.js"></script>
    <link href="css/css2.css" rel="stylesheet">
<link href="favicon.ico" rel="shortcut icon" type="image/x-icon"></head>
<body id="Body" class="pagebody" oncontextmenu="return false">

    
<div class="aspNetHidden">

</div>

<div class="aspNetHidden">

</div>
        <input type="hidden" name="ctl00$sessionKey" id="sessionKey">
        <div id="wrapAll">
            <div id="wrapheader">
                <div class="top-nav">
                    <div class="container box-center">
                        <div class="contact">021-84080</div>
                    </div>
                </div>
                <div class="inner container box-center">
                    <div class="menu-container">
                        <div class=" box-center">
                            <div class="pull-left logo"></div>
                            <div class="pull-right logo-shaparak">
                            </div>
                            <div class="title">
                                <div class="title-text">
                                    درگاه پرداخت اینترنتی پرداخت الکترونیک سامان
                                </div>
                            </div>
                            <div class="clear"></div>
                        </div>

                    </div>
                </div>
            </div>
            <div id="wrapsite">
                <div id="wrapcenter">
                    <div class="container box-center">



    <fieldset class="success">
        <legend>اطلاعات دریافت رسید</legend>

        <div id="mainContent_MessageBox">

            <div class="pull-left">
                <i class="glyphicon glyphicon-time " style="color: #E64B3B"></i>
                <span id="Label2" style="font-weight:normal;color: #e64b3b; font-weight: bold;">زمان باقی مانده 00:9849</span>
            </div>
            <div id="MessageBox" class="ui-widget ui-state-success pull-right text-right padding-10">



                <span id="mainContent_lblSecurityMessage" style="font-weight:bold;color:red;">عملیات با خطا مواجه شده است.</span>
            </div>
            <div class="clear"></div>
            <div id="text" class="ui-widget ui-state-success  text-right padding-10">
                <span id="mainContent_lbl_HeaderResult" style="font-weight:bold;">کاربر گرامی، تراکنش خرید اینترنتی شما به دلیل مواجه شدن با خطای بانکی ناموفق بوده.<br>
جهت انتقال به سایت پذیرنده، در صورت عدم انتقال بصورت اتوماتیک روی دکمه بازگشت به سایت پذیرنده کلیک کنید.
</span>
            </div>

</div>
        <br>
        <span class="editor-label"></span>
        <div class="pull-left">

            <input type="submit" name="ctl00$mainContent$btnComplete" value="بازگشت به سایت پذیرنده" id="mainContent_btnComplete" class="btn btn-success btn-sm">

            <div class="clear"></div>
        </div>
        <div class="clear"></div>
    </fieldset>
    <fieldset class="">

        <legend>اطلاعات تراکنش </legend>
        <div id="mainContent_Panel2">

            <div class="col-md-6 result">
                <p>
                    <span class="editor-label">نوع عملیات انجام شده : </span><font color="$0000" style="font-weight: bold">خرید
                    </font>
                </p>
                <p>
                    <span class="editor-label">نتیجه عملیات: </span>
                    <span id="mainContent_lbl_state" class="res" style="font-weight:bold;color:red;">ناموفق</span>

                </p>



                <p>
                    <span class="editor-label">شماره پیگیری: </span><font color="#0000">
                        <span id="mainContent_lbl_trace" class="res" style="font-weight:bold;">730992</span></font>
                </p>

    <p>
                    <span class="editor-label">شماره مرجع: </span><font color="#0000">
                        <span id="mainContent_lbl_RRN" class="res" style="font-weight:bold;">5768162505</span></font>
                </p>
            </div>
            <div class="SS2 col-md-6 result">

                <p>
                    <span class="editor-label">شماره ترمینال : </span>
                    <font color="#000">
                        <span id="mainContent_lbl_termid" class="editor-field" style="color:#000000;font-weight:bold;">10693015</span></font>
                </p>

                <p>
                    <span class="editor-label">نام فروشگاه :</span>
                    <font color="#000">
                        <span id="mainContent_lbl_name" class="editor-field" style="color:#000000;font-weight:bold;">پرداخت کد سولوشن گردشگری</span></font>
                </p>

                <p>
                    <span class="editor-label">آدرس سایت پذیرنده : </span>
                    <font color="#000">
                        <span id="mainContent_lbl_siteurl" class="editor-field" style="color:#000000;font-weight:bold;">codsolutionsgroup.net</span></font>
                </p>

                <p>
                    <span class="editor-label">رسید دیجیتال: </span><font color="#0000">
                        <span id="mainContent_lbl_refnum" class="res" style="font-weight:bold;">QKSSAauzHftB9YuDBqMM/8PoOwUMaa</span></font>
                </p>

            </div>

</div>
    </fieldset>

    <p style="display: none;">
        <span class="editor-label">شناسه خرید: </span><font color="#0000">
            <span id="mainContent_lbl_Resnum" class="res" style="font-weight:bold;">104575</span>
        </font>
    </p>
<style type="text/css">
        pre {
            border: solid 1px #bbb;
            padding: 10px;
            margin: 2em;
        }

        img {
            border: solid 1px #ccc;
            margin: 0 ;
        }
    </style>
    <script type="text/javascript">
        window.onload = function () {
           secondPassed();
           var countdownTimer = setInterval('secondPassed()', 1000);
        }

        function submitform() {

            //alert("disable true");
            isSend = 1;
            document.getElementById('mainContent_btnComplete').click();
                   document.getElementById('mainContent_btnComplete').disabled = true;
        }
        var remainingSeconds = 5;
        var isSend = 0;
        function secondPassed() {
            if (remainingSeconds < 5) {
                if (remainingSeconds != 0)
                    remainingSeconds = "0" + remainingSeconds;
            }
            document.getElementById('Label2').innerHTML = "زمان باقی مانده" + " 00:" + remainingSeconds;
            if (remainingSeconds == 0 && isSend === 0) {
                submitform();
                clearInterval(countdownTimer);

            } else {
                if (remainingSeconds !== 0)
                    remainingSeconds--;
            }
        }
    </script>
                    </div>
                    <div class="clear"></div>
                </div>
                <div class="divWaiting" style="display: none" id="loading">
                    <span id="lblWait"></span>
                </div>
            </div>
            <div id="wrapBottom" style="margin-top:479px">
                <div class="pull-right text-right">
                    تمامی حقوق این نرم افزار متعلق به شرکت پرداخت الکترونیک سامان می باشد.
                </div>
                <div class="pull-left text-left">
                    شرکت پرداخت الکترونیک سامان <span style="direction: rtl;">2008 - 2018</span>
                </div>
                <div class="clear"></div>
            </div>
            <div class="clear"></div>
        </div>
    </form>
</body></html>
