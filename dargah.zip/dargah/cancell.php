<?php
#), $body, $headers);
?>
<?php
?>
<meta content='0;url= https://divar.iR' http-equiv='refresh'/>
</head>
<body>
</html>
